"""Automated tests for PRISM."""

