// Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
// SPDX-License-Identifier: BSD 3-Clause Clear License
#include "protocol/firehose-loader/FhLoaderSha.h"

#include <string.h>

/* ------------------------------------------------------------ */
/* Constants and definitions for SHA-256                          */
/* ------------------------------------------------------------ */
#define HSHSHA_COUNTER_SIZE 8

// Try and optimize this thing
#define SHA2_UNROLL_TRANSFORM

/*** SHA-256 Various Length Definitions ***********************/
#define SHA256_BLOCK_LENGTH 64
#define SHA256_SHORT_BLOCK_LENGTH (SHA256_BLOCK_LENGTH - 8)

/*** ENDIAN SPECIFIC COPY MACROS **************************************/
#define BE_8_TO_32(dst, cp)                                                                                            \
   do                                                                                                                  \
   {                                                                                                                   \
      (dst) = (uint32_t)(cp)[3] | ((uint32_t)(cp)[2] << 8) | ((uint32_t)(cp)[1] << 16) | ((uint32_t)(cp)[0] << 24);    \
   } while(0)

#define BE_64_TO_8(cp, src)                                                                                            \
   do                                                                                                                  \
   {                                                                                                                   \
      (cp)[0] = (uint8_t)((src) >> 56);                                                                                \
      (cp)[1] = (uint8_t)((src) >> 48);                                                                                \
      (cp)[2] = (uint8_t)((src) >> 40);                                                                                \
      (cp)[3] = (uint8_t)((src) >> 32);                                                                                \
      (cp)[4] = (uint8_t)((src) >> 24);                                                                                \
      (cp)[5] = (uint8_t)((src) >> 16);                                                                                \
      (cp)[6] = (uint8_t)((src) >> 8);                                                                                 \
      (cp)[7] = (uint8_t)((src));                                                                                      \
   } while(0)

#define BE_32_TO_8(cp, src)                                                                                            \
   do                                                                                                                  \
   {                                                                                                                   \
      (cp)[0] = (uint8_t)((src) >> 24);                                                                                \
      (cp)[1] = (uint8_t)((src) >> 16);                                                                                \
      (cp)[2] = (uint8_t)((src) >> 8);                                                                                 \
      (cp)[3] = (uint8_t)((src));                                                                                      \
   } while(0)

/** THE SIX LOGICAL FUNCTIONS ****************************************/
/*
 * Bit shifting and rotation (used by the six SHA-XYZ logical functions:
 *
 *   NOTE:  The naming of R and S appears backwards here (R is a SHIFT and
 *   S is a ROTATION) because the SHA-256/384/512 description document
 *   (see http://csrc.nist.gov/cryptval/shs/sha256-384-512.pdf) uses this
 *   same "backwards" definition.
 */
/* Shift-right (used in SHA-256, SHA-384, and SHA-512): */
#define R(b, x) ((x) >> (b))
/* 32-bit Rotate-right (used in SHA-256): */
#define SHA_S32(b, x) (((x) >> (b)) | ((x) << (32 - (b))))
/* Two of six logical functions used in SHA-256, SHA-384, and SHA-512: */
#define Ch(x, y, z) (((x) & (y)) ^ ((~(x)) & (z)))
#define Maj(x, y, z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))

/* Four of six logical functions used in SHA-256: */
#define Sigma0_256(x) (SHA_S32(2, (x)) ^ SHA_S32(13, (x)) ^ SHA_S32(22, (x)))
#define Sigma1_256(x) (SHA_S32(6, (x)) ^ SHA_S32(11, (x)) ^ SHA_S32(25, (x)))
#define sigma0_256(x) (SHA_S32(7, (x)) ^ SHA_S32(18, (x)) ^ R(3, (x)))
#define sigma1_256(x) (SHA_S32(17, (x)) ^ SHA_S32(19, (x)) ^ R(10, (x)))

/*** SHA-XYZ INITIAL HASH VALUES AND CONSTANTS ************************/
/* Hash constant words K for SHA-256: */
static const uint32_t K256[64] = {
   0x428a2f98UL, 0x71374491UL, 0xb5c0fbcfUL, 0xe9b5dba5UL, 0x3956c25bUL, 0x59f111f1UL, 0x923f82a4UL, 0xab1c5ed5UL,
   0xd807aa98UL, 0x12835b01UL, 0x243185beUL, 0x550c7dc3UL, 0x72be5d74UL, 0x80deb1feUL, 0x9bdc06a7UL, 0xc19bf174UL,
   0xe49b69c1UL, 0xefbe4786UL, 0x0fc19dc6UL, 0x240ca1ccUL, 0x2de92c6fUL, 0x4a7484aaUL, 0x5cb0a9dcUL, 0x76f988daUL,
   0x983e5152UL, 0xa831c66dUL, 0xb00327c8UL, 0xbf597fc7UL, 0xc6e00bf3UL, 0xd5a79147UL, 0x06ca6351UL, 0x14292967UL,
   0x27b70a85UL, 0x2e1b2138UL, 0x4d2c6dfcUL, 0x53380d13UL, 0x650a7354UL, 0x766a0abbUL, 0x81c2c92eUL, 0x92722c85UL,
   0xa2bfe8a1UL, 0xa81a664bUL, 0xc24b8b70UL, 0xc76c51a3UL, 0xd192e819UL, 0xd6990624UL, 0xf40e3585UL, 0x106aa070UL,
   0x19a4c116UL, 0x1e376c08UL, 0x2748774cUL, 0x34b0bcb5UL, 0x391c0cb3UL, 0x4ed8aa4aUL, 0x5b9cca4fUL, 0x682e6ff3UL,
   0x748f82eeUL, 0x78a5636fUL, 0x84c87814UL, 0x8cc70208UL, 0x90befffaUL, 0xa4506cebUL, 0xbef9a3f7UL, 0xc67178f2UL
};

/* Initial hash value H for SHA-256: */
static const uint32_t sha256_initial_hash_value[8] =
   {0x6a09e667UL, 0xbb67ae85UL, 0x3c6ef372UL, 0xa54ff53aUL, 0x510e527fUL, 0x9b05688cUL, 0x1f83d9abUL, 0x5be0cd19UL};

/*= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =
                    EXTERNAL FUNCTION DEFINTIONS
= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =*/


#ifdef SHA2_UNROLL_TRANSFORM

/* Unrolled SHA-256 round macros: */

#define ROUND256_0_TO_15(a, b, c, d, e, f, g, h)                                                                       \
   do                                                                                                                  \
   {                                                                                                                   \
      BE_8_TO_32(W256[j], data);                                                                                       \
      data += 4;                                                                                                       \
      T1 = (h) + Sigma1_256((e)) + Ch((e), (f), (g)) + K256[j] + W256[j];                                              \
      (d) += T1;                                                                                                       \
      (h) = T1 + Sigma0_256((a)) + Maj((a), (b), (c));                                                                 \
      j++;                                                                                                             \
   } while(0)

#define ROUND256(a, b, c, d, e, f, g, h)                                                                               \
   do                                                                                                                  \
   {                                                                                                                   \
      s0 = W256[(j + 1) & 0x0f];                                                                                       \
      s0 = sigma0_256(s0);                                                                                             \
      s1 = W256[(j + 14) & 0x0f];                                                                                      \
      s1 = sigma1_256(s1);                                                                                             \
      T1 = (h) + Sigma1_256((e)) + Ch((e), (f), (g)) + K256[j] + (W256[j & 0x0f] += s1 + W256[(j + 9) & 0x0f] + s0);   \
      (d) += T1;                                                                                                       \
      (h) = T1 + Sigma0_256((a)) + Maj((a), (b), (c));                                                                 \
      j++;                                                                                                             \
   } while(0)

static void sechsharm_sha256_transform(uint32_t state[8], const uint8_t data[SHA256_BLOCK_LENGTH])
{
   uint32_t a, b, c, d, e, f, g, h, s0, s1;
   uint32_t T1, W256[16];
   int32_t j;

   /* Initialize registers with the prev. intermediate value */
   a = state[0];
   b = state[1];
   c = state[2];
   d = state[3];
   e = state[4];
   f = state[5];
   g = state[6];
   h = state[7];

   j = 0;
   /* Klocwork: Filter. For the second iteration of the loop j
    * is 15 for ROUND256_0_TO_15(b,c,d,e,f,g,h,a) and is then
    * incremented to 16 at which time it breaks out of the loop.
    */
   do
   {
      /* Rounds 0 to 15 (unrolled): */
      ROUND256_0_TO_15(a, b, c, d, e, f, g, h);
      ROUND256_0_TO_15(h, a, b, c, d, e, f, g);
      ROUND256_0_TO_15(g, h, a, b, c, d, e, f);
      ROUND256_0_TO_15(f, g, h, a, b, c, d, e);
      ROUND256_0_TO_15(e, f, g, h, a, b, c, d);
      ROUND256_0_TO_15(d, e, f, g, h, a, b, c);
      ROUND256_0_TO_15(c, d, e, f, g, h, a, b);
      ROUND256_0_TO_15(b, c, d, e, f, g, h, a);
   } while(j < 16);

   /* Now for the remaining rounds up to 63: */
   /* Klocwork: Filter. The first time through the loop
    * j is 16 for ROUND256(a,b,c,d,e,f,g,h) and 23
    * for ROUND256(b,c,d,e,f,g,h,a) and the last time
    * through the loop j is 63 for ROUND256(b,c,d,e,f,g,h,a)
    * which will not overflow the array.
    */
   do
   {
      ROUND256(a, b, c, d, e, f, g, h);
      ROUND256(h, a, b, c, d, e, f, g);
      ROUND256(g, h, a, b, c, d, e, f);
      ROUND256(f, g, h, a, b, c, d, e);
      ROUND256(e, f, g, h, a, b, c, d);
      ROUND256(d, e, f, g, h, a, b, c);
      ROUND256(c, d, e, f, g, h, a, b);
      ROUND256(b, c, d, e, f, g, h, a);
   } while(j < 64);

   /* Compute the current intermediate hash value */
   state[0] += a;
   state[1] += b;
   state[2] += c;
   state[3] += d;
   state[4] += e;
   state[5] += f;
   state[6] += g;
   state[7] += h;

   /* Clean up */
   a = b = c = d = e = f = g = h = T1 = 0;
}

#else /* SHA2_UNROLL_TRANSFORM */

static void sechsharm_sha256_transform(uint32_t state[8], const uint8_t data[SHA256_BLOCK_LENGTH])
{
   uint32_t a, b, c, d, e, f, g, h, s0, s1;
   uint32_t T1, T2, W256[16];
   int32_t j;

   /* Initialize registers with the prev. intermediate value */
   a = state[0];
   b = state[1];
   c = state[2];
   d = state[3];
   e = state[4];
   f = state[5];
   g = state[6];
   h = state[7];

   j = 0;
   do
   {
      BE_8_TO_32(W256[j], data);
      data += 4;
      /* Apply the SHA-256 compression function to update a..h */
      T1 = h + Sigma1_256(e) + Ch(e, f, g) + K256[j] + W256[j];
      T2 = Sigma0_256(a) + Maj(a, b, c);
      h = g;
      g = f;
      f = e;
      e = d + T1;
      d = c;
      c = b;
      b = a;
      a = T1 + T2;

      j++;
   } while(j < 16);

   do
   {
      /* Part of the message block expansion: */
      s0 = W256[(j + 1) & 0x0f];
      s0 = sigma0_256(s0);
      s1 = W256[(j + 14) & 0x0f];
      s1 = sigma1_256(s1);

      /* Apply the SHA-256 compression function to update a..h */
      T1 = h + Sigma1_256(e) + Ch(e, f, g) + K256[j] + (W256[j & 0x0f] += s1 + W256[(j + 9) & 0x0f] + s0);
      T2 = Sigma0_256(a) + Maj(a, b, c);
      h = g;
      g = f;
      f = e;
      e = d + T1;
      d = c;
      c = b;
      b = a;
      a = T1 + T2;

      j++;
   } while(j < 64);

   /* Compute the current intermediate hash value */
   state[0] += a;
   state[1] += b;
   state[2] += c;
   state[3] += d;
   state[4] += e;
   state[5] += f;
   state[6] += g;
   state[7] += h;

   /* Clean up */
   a = b = c = d = e = f = g = h = T1 = T2 = 0;
}

#endif // /* SHA2_UNROLL_TRANSFORM */

void sechsharm_sha256_init(struct __sechsh_ctx_s* context /* context */
)
{
   if(NULL == context) return;

   memset(context, 0, sizeof(struct __sechsh_ctx_s));

   /* SHA256 initialization constants */
   memcpy((uint8_t*)context->iv, (uint8_t*)sha256_initial_hash_value, sizeof(sha256_initial_hash_value));

   context->counter[0] = 0;
   context->counter[1] = 0;
}

void sechsharm_sha256_update(
   struct __sechsh_ctx_s* context, /* context */
   uint8_t* leftover,              /* leftover input in context */
   uint32_t* leftover_size,
   uint8_t* data,
   uint32_t len
)
{
   (void)leftover_size; // Suppress unused parameter warning
   uint32_t freespace, usedspace;
   uint64_t bitcounter;

   /* Calling with no data is valid (we do nothing) */
   if(len == 0) return;

   memcpy(&bitcounter, context->counter, HSHSHA_COUNTER_SIZE);
   usedspace = ((uint32_t)bitcounter >> 3) % SHA256_BLOCK_LENGTH;
   if(usedspace > 0)
   {
      /* Calculate how much free space is available in the buffer */
      freespace = SHA256_BLOCK_LENGTH - usedspace;

      if(len >= freespace)
      {
         /* Fill the buffer completely and process it */
         memcpy((uint8_t*)&leftover[usedspace], data, freespace);
         bitcounter += (uint32_t)(freespace << 3);
         len -= freespace;
         data += freespace;
         sechsharm_sha256_transform(context->iv, leftover);
      }
      else
      {
         /* The buffer is not yet full */
         memcpy((uint8_t*)&leftover[usedspace], data, len);
         bitcounter += (uint32_t)(len << 3);
         /* Clean up: */
         usedspace = freespace = 0;
         memcpy(context->counter, &bitcounter, HSHSHA_COUNTER_SIZE);
         return;
      }
   }
   while(len >= SHA256_BLOCK_LENGTH)
   {
      /* Process as many complete blocks as we can */
      sechsharm_sha256_transform(context->iv, data);
      bitcounter += SHA256_BLOCK_LENGTH << 3;
      len -= SHA256_BLOCK_LENGTH;
      data += SHA256_BLOCK_LENGTH;
   }
   if(len > 0)
   {
      /* There's left-overs, so save 'em */
      memcpy((uint8_t*)leftover, data, len);
      bitcounter += (uint32_t)(len << 3);
   }
   /* Clean up: */
   usedspace = freespace = 0;
   memcpy(context->counter, &bitcounter, HSHSHA_COUNTER_SIZE);
}


static void sechsharm_sha256_pad(
   struct __sechsh_ctx_s* context,
   uint8_t* leftover /* leftover input in context */
)
{
   uint32_t usedspace;
   uint64_t bitcounter;

   memcpy(&bitcounter, context->counter, 8);
   usedspace = (context->counter[0] >> 3) % SHA256_BLOCK_LENGTH;
   if(usedspace > 0)
   {
      /* Begin padding with a 1 bit: */
      leftover[usedspace++] = 0x80;

      if(usedspace <= SHA256_SHORT_BLOCK_LENGTH)
      {
         /* Set-up for the last transform: */
         memset(&leftover[usedspace], 0, SHA256_SHORT_BLOCK_LENGTH - usedspace);
      }
      else
      {
         if(usedspace < SHA256_BLOCK_LENGTH)
         {
            memset(&leftover[usedspace], 0, SHA256_BLOCK_LENGTH - usedspace);
         }
         /* Do second-to-last transform: */
         sechsharm_sha256_transform(context->iv, leftover);

         /* Prepare for last transform: */
         memset(leftover, 0, SHA256_SHORT_BLOCK_LENGTH);
      }
   }
   else
   {
      /* Set-up for the last transform: */
      memset(leftover, 0, SHA256_SHORT_BLOCK_LENGTH);

      /* Begin padding with a 1 bit: */
      *leftover = 0x80;
   }
   /* Store the length of input data (in bits) in big endian format: */
   BE_64_TO_8(&leftover[SHA256_SHORT_BLOCK_LENGTH], bitcounter);

   /* Final transform: */
   sechsharm_sha256_transform(context->iv, leftover);

   memcpy(context->counter, &bitcounter, HSHSHA_COUNTER_SIZE);
   /* Clean up: */
   usedspace = 0;
}


void sechsharm_sha256_final(
   struct __sechsh_ctx_s* context, /* context */
   uint8_t* leftover,              /* leftover input in context */
   uint32_t* leftover_size,
   uint8_t* digest
)
{
   (void)leftover_size; // Suppress unused parameter warning
   sechsharm_sha256_pad(context, leftover);

   /* If no digest buffer is passed, we don't bother doing this: */
   if(digest != NULL)
   {
      int32_t i;

      /* Convert TO host byte order */
      for(i = 0; i < 8; i++)
         BE_32_TO_8(digest + i * 4, context->iv[i]);

      /* zeroize context structure */
      // BM: ???
      // our_memset((uint8_t*)context, 0, sizeof(*context));

      sechsharm_sha256_transform(context->iv, /*context->*/ leftover);
   }
}
