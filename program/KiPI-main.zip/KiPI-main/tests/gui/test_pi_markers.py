"""PI Models markers in the 3D view (#84): the DC setup's VRMs, loads and series links,
marked on their pads over the copper (not over results)."""

import os
from types import MethodType
from types import SimpleNamespace as NS

import numpy as np
import pytest

from kipi.dc.pi.model import DcLink, PinRef
from kipi.ac.viz.markers import ac_markers
from kipi.dc.viz.markers import LIFT_MM, pi_markers
from phase_boards import T, board, two_phase
from shapely.geometry import box
from tree_boards import B, pad


def _by_name(markers):
    return {m.name: m for m in markers}


def test_markers_sit_on_the_pads_of_the_shown_nets():
    snap, setup = board(), two_phase(ground=True)
    top, bottom_cu_top = 1.5 + 2 * T + LIFT_MM, T + LIFT_MM
    m = _by_name(pi_markers(snap, setup, {"VOUT"}))
    assert set(m) == {"VRM U1", "Load U2"}                # J1 is only on VIN and GND
    assert m["VRM U1"].kind == "vrm" and m["Load U2"].kind == "load"
    np.testing.assert_allclose(m["VRM U1"].power, [[0.5, 0.5, top], [19.5, 0.5, top]])
    assert len(m["VRM U1"].ground) == 0                  # GND is not shown
    np.testing.assert_allclose(m["Load U2"].anchor, [5.5, 0.5, top])

    m = _by_name(pi_markers(snap, setup, {"VOUT", "VIN", "GND"}))
    assert len(m["VRM U1"].power) == 4                    # both phases' output and input
    np.testing.assert_allclose(m["VRM U1"].ground, [[9.5, 0.5, bottom_cu_top],
                                                    [19.5, 0.5, bottom_cu_top]])
    assert len(m["VRM J1"].power) == 1 and len(m["VRM J1"].ground) == 1
    assert pi_markers(snap, setup, set()) == [] and pi_markers(None, setup, {"VOUT"}) == []


def test_links_and_parts_under_the_board():
    from kipi.core.model.board import Footprint
    snap, setup = board(), two_phase()
    setup.links.append(DcLink("FB1", PinRef("L1", "VOUT", ["2"]), PinRef("Q1", "VIN", ["1"]),
                              0.01))
    snap.footprints.append(Footprint("fq1", "Q1", "", (9.5, 3.5), "bottom", ["q1_1"]))
    m = _by_name(pi_markers(snap, setup, {"VOUT", "VIN"}))
    link = m["Link FB1"]
    assert link.kind == "link" and len(link.power) == 2
    # Q1 is under the board: its pad is marked below the top copper's bottom face.
    q1 = next(p for p in link.power if p[0] == 9.5)
    assert q1[2] == pytest.approx(1.5 + T - LIFT_MM)


def test_capacitors_with_a_model_are_marked_by_reference_in_ac_mode_only():
    from kipi.ac.model import CapModel
    snap, setup = board(), two_phase()
    snap.pads.append(pad("c1_1", "VOUT", "C1", "1", box(2, 0, 3, 1)))
    snap.pads.append(pad("c1_2", "GND", "C1", "2", box(2, 0, 3, 1), B))
    snap.pads.append(pad("c2_1", "VOUT", "C2", "1", box(3, 0, 4, 1)))
    setup.caps.append(CapModel("10u", 10e-6, 1e-9, 0.005, ["C1"]))   # C2 has no model
    assert "C1" not in _by_name(pi_markers(snap, setup, {"VOUT", "GND"}))  # not DC mode's
    m = _by_name(ac_markers(snap, setup, {"VOUT", "GND"}))
    assert "C2" not in m and m["C1"].kind == "cap"
    np.testing.assert_allclose(m["C1"].power, [[2.5, 0.5, 1.5 + 2 * T + LIFT_MM]])
    np.testing.assert_allclose(m["C1"].ground, [[2.5, 0.5, T + LIFT_MM]])  # GND by name
    assert "C1" not in _by_name(ac_markers(snap, setup, {"VIN"}))


def _two_caps(snap, setup):
    from kipi.ac.model import CapModel
    snap.pads.append(pad("c1_1", "VOUT", "C1", "1", box(2, 0, 3, 1)))
    snap.pads.append(pad("c2_1", "VOUT", "C2", "1", box(12, 0, 13, 1)))
    setup.caps.append(CapModel("10u", 10e-6, 1e-9, 0.005, ["C1", "C2"]))
    setup.caps.append(CapModel("bulk", 10e-6, 1e-9, 0.005, ["C2"]))


def test_a_capacitor_model_is_every_part_it_names():
    snap, setup = board(), two_phase()
    _two_caps(snap, setup)
    m = _by_name(ac_markers(snap, setup, {"VOUT"}))
    assert m["C1"].models == ("10u",) and m["C2"].models == ("10u", "bulk")
    assert [n for n, x in m.items() if x.is_item("cap", "10u")] == ["C1", "C2"]
    assert [n for n, x in m.items() if x.is_item("cap", "bulk")] == ["C2"]
    assert not m["C1"].is_item("cap", "C1")               # a model's name, not a part's
    assert m["C2"].setup_item == "10u" and m["VRM U1"].setup_item == "U1"


# --- Drawing -----------------------------------------------------------------------------

pv = pytest.importorskip("pyvista")
pytest.importorskip("pyvistaqt")
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from kipi.gui.viewer3d import Viewer3D  # noqa: E402


class _Timer:
    """Stands in for the blink QTimer: the test steps it by hand."""
    active = False

    def start(self):
        self.active = True

    def stop(self):
        self.active = False

    def setInterval(self, ms):
        self.interval = ms


def _view():
    v = NS(plotter=pv.Plotter(off_screen=True), _models={}, _model_actors={}, _board_top=0.0,
           _model_board=0.0, _zscale=1.0, _show_models=True, _show_models_result=False,
           _show_board=True, _show_vias=True, _show_pi=True, _pi_markers=[], _pi_actors={},
           _pi_selected=None, _blink_left=0, _blink_timer=_Timer(),
           _result=None, _result_field="voltage", _chunk_actors={}, _result_actors={},
           _arrow_actors={}, _result_via_actor=None, _board_actors=[], _hidden_layers=set(),
           _coating_actors=[], _show_mask=False, _show_silk=False,
           _show_mask_result=False, _show_silk_result=False, _coupling=None,
           _coupling_actors=[], _coupling_bar=None, _coupling_title=None, _hot_loops=None,
           _hot_loop_actors=[], _fields=None, _field_actors=[], _field_bar=None,
           _field_title=None, _field_mesh=None, _field_arrows=None, _field_frame=0,
           _field_timer=_Timer())
    for name in ("set_pi_markers", "_draw_pi_markers", "_remove_pi_actors", "_apply_visibility", "set_zscale",
                 "set_feature_visible", "_place_models", "_selected_markers", "set_pi_selected",
                 "pi_marker_at", "_to_screen", "focus_on", "_start_blink", "_blink_step",
                 "_paint_selected", "set_coupling", "_remove_coupling_actors",
                 "_draw_coupling", "set_hot_loops", "_remove_hot_loop_actors",
                 "_draw_hot_loops", "set_fields", "_remove_field_actors", "_draw_fields",
                 "_field_arrow_mesh", "_field_step"):
        setattr(v, name, MethodType(getattr(Viewer3D, name), v))
    return v


def _visible(v):
    return {n for n, a in v._pi_actors.items() if a.GetVisibility()}


def test_markers_are_drawn_over_the_copper_only():
    v = _view()
    v.set_pi_markers(pi_markers(board(), two_phase(ground=True), {"VOUT", "GND"}))
    names = {"pi_vrm_power", "pi_vrm_ground", "pi_vrm_labels", "pi_load_power",
             "pi_load_ground", "pi_load_labels"}
    assert set(v._pi_actors) == names == _visible(v)
    assert not any(a.GetPickable() for a in v._pi_actors.values())
    v.set_feature_visible("pi", False)
    assert _visible(v) == set()
    v.set_feature_visible("pi", True)
    v._result = object()                                  # results are shown
    v._apply_visibility()
    assert _visible(v) == set()
    v._result = None
    v._apply_visibility()
    assert _visible(v) == names
    props = v.plotter.renderer.GetViewProps()
    assert all(props.IsItemPresent(a) for a in v._pi_actors.values())
    v.set_pi_markers([])                                  # AC mode
    assert v._pi_actors == {} and props.GetNumberOfItems() == 0


def test_ac_mode_draws_its_probes_in_their_own_color():
    from kipi.ac.model import Probe
    from kipi.ac.viz.markers import ac_markers
    from kipi.gui.viewer3d import _PI_COLORS
    v = _view()
    setup = two_phase(ground=True)
    setup.probes.append(Probe("U2 core", PinRef("U2", "VOUT", ["1"]),
                              PinRef("U2", "GND", ["2"])))
    v.set_pi_markers(ac_markers(board(), setup, {"VOUT", "GND"}))
    assert set(v._pi_actors) == {"pi_vrm_power", "pi_vrm_ground", "pi_vrm_labels",
                                "pi_probe_power", "pi_probe_ground",
                                "pi_probe_labels"} == _visible(v)
    dots = v._pi_actors["pi_probe_power"]
    np.testing.assert_allclose(dots.GetProperty().GetColor(), _PI_COLORS["probe"][0])
    assert _PI_COLORS["probe"] not in [c for k, c in _PI_COLORS.items() if k != "probe"]
    v.set_feature_visible("pi", False)
    assert _visible(v) == set()


def test_markers_follow_the_z_scale():
    v = _view()
    v.set_pi_markers(pi_markers(board(), two_phase(), {"VOUT"}))
    z = lambda: v._pi_actors["pi_load_power"].GetMapper().GetInput().GetPoint(0)[2]  # noqa: E731
    z1 = z()
    v.set_zscale(4.0)
    assert z() == pytest.approx(4 * z1)


def test_the_part_selected_in_the_setup_is_marked():
    """#96: larger amber dots on its pads and its name, over its own marker."""
    v = _view()
    v.set_pi_markers(pi_markers(board(), two_phase(ground=True), {"VOUT", "GND"}))
    v.set_pi_selected(("vrm", "U1"))
    dots = v._pi_actors["pi_selected_dots"]
    vrm = next(m for m in v._pi_markers if m.item == "U1")
    assert dots.GetMapper().GetInput().GetNumberOfPoints() == len(vrm.power) + len(vrm.ground)
    assert "pi_selected_label" in v._pi_actors
    names = list(v._pi_actors)
    assert names[-2:] == ["pi_selected_dots", "pi_selected_label"]      # drawn last
    v.set_feature_visible("pi", False)                    # shown with the markers
    assert not dots.GetVisibility()
    v.set_pi_selected(("load", "nothing such"))
    assert "pi_selected_dots" not in v._pi_actors
    assert not v._blink_timer.active                      # nothing selected to blink
    v.set_pi_selected(None)
    assert "pi_selected_label" not in v._pi_actors


def test_the_selected_part_blinks_then_stays_amber():
    from kipi.gui.viewer3d import _PI_BLINK_COLORS, _PI_BLINKS, _PI_SELECTED_COLORS
    v = _view()
    v.set_pi_markers(pi_markers(board(), two_phase(ground=True), {"VOUT", "GND"}))
    v.set_pi_selected(("vrm", "U1"))
    assert v._blink_timer.active

    def colors():
        dots = v._pi_actors["pi_selected_dots"].GetProperty().GetColor()
        label = (v._pi_actors["pi_selected_label"].GetMapper().GetLabelTextProperty()
                 .GetBackgroundColor())
        return tuple(round(c, 6) for c in (*dots, *label))

    blink = tuple(round(c, 6) for c in (*_PI_BLINK_COLORS[0], *_PI_BLINK_COLORS[1]))
    amber = tuple(round(c, 6) for c in (*_PI_SELECTED_COLORS[0], *_PI_SELECTED_COLORS[1]))

    seen = []
    for _ in range(2 * _PI_BLINKS):
        v._blink_step()
        seen.append(colors())
    assert seen == [blink, amber] * _PI_BLINKS            # ends amber
    assert not v._blink_timer.active
    v.set_pi_selected(("load", "U2"))                     # another part blinks afresh
    assert v._blink_timer.active and v._blink_left == 2 * _PI_BLINKS


def _looking_down(v):
    v.plotter.view_xy()
    v.plotter.reset_camera(bounds=(0, 25, -10, 5, 0, 2))
    v.plotter.render()


def test_a_click_on_a_name_or_dot_finds_its_marker():
    v = _view()
    v.set_pi_markers(pi_markers(board(), two_phase(ground=True), {"VOUT", "GND"}))
    _looking_down(v)
    load = next(m for m in v._pi_markers if m.kind == "load")
    anchor = [*load.anchor[:2], load.anchor[2] + 1.0]     # the name sits above the dots
    (x, y), = v._to_screen(np.array([anchor]))[0]
    assert v.pi_marker_at((x + 5, y + 3)) is load
    (px, py) = v._to_screen(load.power)[0][0]
    assert v.pi_marker_at((px + 2, py)) is not None
    assert v.pi_marker_at((x + 2000, y)) is None
    v.set_feature_visible("pi", False)                    # hidden markers are not clicked
    assert v.pi_marker_at((x, y)) is None


def test_focus_brings_the_view_to_the_part():
    v = _view()
    _looking_down(v)
    cam = v.plotter.renderer.GetActiveCamera()
    before = np.linalg.norm(np.array(cam.GetPosition()) - cam.GetFocalPoint())
    v.focus_on(np.array([[10.0, 2.0, 1.6], [12.0, 2.0, 1.6]]))
    np.testing.assert_allclose(cam.GetFocalPoint(), [11.0, -2.0, 1.6])
    after = np.linalg.norm(np.array(cam.GetPosition()) - cam.GetFocalPoint())
    assert after < before                                 # nearer: a part, not the board
    np.testing.assert_allclose(cam.GetDirectionOfProjection(), [0, 0, -1], atol=1e-9)


# --- The window ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def app():
    from qtpy.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def test_the_window_marks_each_modes_parts(app, no_3d, monkeypatch):
    """DC mode marks the loads; AC mode marks the probes in their place (#84)."""
    from qtpy.QtWidgets import QCheckBox
    from kipi.ac.model import Probe
    from kipi.gui.main_window import MainWindow
    w = MainWindow()
    labels = [cb.text() for cb in w.findChildren(QCheckBox)]
    assert "PI Models" in labels and "3D Models" in labels and "Models" not in labels
    assert not w.chk_pi.isChecked() and w.chk_models.text() == "3D Models"
    w.snapshot = board()
    w.solve_panel.setup = two_phase()
    w.solve_panel.setup.probes.append(Probe("U2 core", PinRef("U2", "VOUT", ["1"]),
                                            PinRef("U2", "GND", ["2"])))
    monkeypatch.setattr(w, "_checked_set", lambda: frozenset({"VOUT"}))
    drawn = []
    w.viewer.set_pi_markers = lambda markers: drawn.append([m.name for m in markers])
    w._sync_pi_markers()
    assert drawn[-1] == ["VRM U1", "Load U2"]
    w.set_mode("ac")
    assert drawn[-1] == ["VRM U1", "Probe U2 core"]
    w.set_mode("dc")
    assert drawn[-1] == ["VRM U1", "Load U2"]
    w.snapshot = None                                     # no board: nothing to mark
    w._sync_pi_markers()
    assert drawn[-1] == []
    w.close()


def test_picking_a_part_in_the_setup_marks_it_and_goes_there(app, no_3d, monkeypatch):
    from kipi.gui.main_window import MainWindow
    w = MainWindow()
    w.snapshot = board()
    w.solve_panel.setup = two_phase()
    w.solve_panel.vrm_list.reload()
    w.solve_panel.load_list.reload()
    monkeypatch.setattr(w, "_checked_set", lambda: frozenset({"VOUT"}))
    w._sync_pi_markers()
    marked, focused = [], []
    monkeypatch.setattr(w.viewer, "set_pi_selected", marked.append)
    monkeypatch.setattr(w.viewer, "focus_on", focused.append)
    w.chk_snap.blockSignals(True)                 # not saved to the user's settings
    w.chk_snap.setChecked(True)
    lst = w.solve_panel.load_list
    w.solve_panel.tabs.setCurrentWidget(lst)
    assert marked[-1] == ("load", "U2") and not focused       # shown, not flown to
    assert not w.chk_pi.isChecked() and not w.chk_snap.isEnabled()
    lst.lst.itemClicked.emit(lst.lst.item(0))                 # the user clicks it
    assert not w.chk_pi.isChecked() and not focused           # PI Models stays off
    w.chk_pi.setChecked(True)
    assert w.chk_snap.isEnabled()
    lst.lst.itemClicked.emit(lst.lst.item(0))
    assert len(focused) == 1
    np.testing.assert_allclose(focused[0][:, :2].mean(axis=0), [5.5, 0.5])
    w.chk_snap.setChecked(False)                              # marked, but the view stays
    lst.lst.itemClicked.emit(lst.lst.item(0))
    assert marked[-1] == ("load", "U2") and len(focused) == 1
    w.solve_panel.tabs.setCurrentIndex(3)                     # the Solve tab: none
    assert marked[-1] is None
    w.close()


def test_clicking_a_name_in_3d_selects_the_part(app, no_3d, monkeypatch):
    from kipi.gui.main_window import MainWindow
    w = MainWindow()
    w.snapshot = board()
    w.solve_panel.setup = two_phase()
    for il in (w.solve_panel.vrm_list, w.solve_panel.load_list):
        il.reload()
    monkeypatch.setattr(w, "_checked_set", lambda: frozenset({"VOUT"}))
    w._sync_pi_markers()
    load = next(m for m in w.viewer.pi_markers if m.kind == "load")
    monkeypatch.setattr(w.viewer, "pi_marker_at", lambda xy: load)
    picked = []
    monkeypatch.setattr(w, "_on_pick", lambda *a: picked.append(a))
    w._on_click((5.5, 0.5, 1.6), (10, 10))
    assert w.solve_panel.tabs.currentWidget() is w.solve_panel.load_list
    assert w.solve_panel.load_list.current().name == "U2"
    assert picked == []                                       # not a copper pick
    w.close()


def _ac_window(monkeypatch):
    from kipi.ac.model import Probe
    from kipi.gui.main_window import MainWindow
    w = MainWindow()
    w.snapshot = board()
    setup = two_phase()
    setup.probes.append(Probe("U2 core", PinRef("U2", "VOUT", ["1"]),
                              PinRef("U2", "GND", ["2"])))
    w.solve_panel.setup = w.ac_panel.setup = setup         # the panels share one setup
    monkeypatch.setattr(w, "_checked_set", lambda: frozenset({"VOUT"}))
    w.solve_panel.load_list.reload()
    w.set_mode("ac")
    for il in w.ac_panel._lists():
        il.reload()
    return w


def test_picking_a_probe_in_the_ac_setup_marks_it_and_goes_there(app, no_3d, monkeypatch):
    w = _ac_window(monkeypatch)
    marked, focused = [], []
    monkeypatch.setattr(w.viewer, "set_pi_selected", marked.append)
    monkeypatch.setattr(w.viewer, "focus_on", focused.append)
    lst = w.ac_panel.probe_list
    w.ac_panel.tabs.setCurrentWidget(lst)
    assert marked[-1] == ("probe", "U2 core") and not focused  # shown, not flown to
    assert not w.chk_pi.isChecked()
    lst.lst.itemClicked.emit(lst.lst.item(0))                  # the user clicks it
    assert not w.chk_pi.isChecked() and not focused            # PI Models stays off
    w.chk_snap.blockSignals(True)                  # not saved to the user's settings
    w.chk_snap.setChecked(True)
    w.chk_pi.setChecked(True)
    lst.lst.itemClicked.emit(lst.lst.item(0))
    assert len(focused) == 1
    np.testing.assert_allclose(focused[0][:, :2].mean(axis=0), [5.5, 0.5])
    w.ac_panel.tabs.setCurrentWidget(w.ac_panel.cap_list)      # no capacitor models
    assert marked[-1] is None
    w.ac_panel.tabs.setCurrentWidget(w.ac_panel.vrm_list)
    assert marked[-1] == ("vrm", "J1")
    # The DC panel's lists say nothing while AC mode shows, and the mode switch brings
    # back its own selection.
    w.solve_panel.tabs.setCurrentWidget(w.solve_panel.load_list)
    assert marked[-1] == ("vrm", "J1")
    w.set_mode("dc")
    assert marked[-1][0] == "load"
    w.set_mode("ac")
    assert marked[-1] == ("vrm", "J1")
    w.close()


def test_picking_a_capacitor_model_marks_its_parts_and_goes_there(app, no_3d, monkeypatch):
    w = _ac_window(monkeypatch)
    _two_caps(w.snapshot, w.ac_panel.setup)
    w.ac_panel.cap_list.reload()
    w._sync_pi_markers()
    marked, focused = [], []
    monkeypatch.setattr(w.viewer, "set_pi_selected", marked.append)
    monkeypatch.setattr(w.viewer, "focus_on", focused.append)
    w.chk_snap.blockSignals(True)                  # not saved to the user's settings
    w.chk_snap.setChecked(True)
    w.chk_pi.setChecked(True)
    lst = w.ac_panel.cap_list
    w.ac_panel.tabs.setCurrentWidget(lst)
    assert marked[-1] == ("cap", "10u") and not focused
    lst.lst.itemClicked.emit(lst.lst.item(0))
    assert len(focused) == 1
    np.testing.assert_allclose(focused[0][:, :2].mean(axis=0), [7.5, 0.5])   # C1 and C2
    w.close()


def test_a_capacitor_model_lights_up_all_its_parts():
    v = _view()
    snap, setup = board(), two_phase()
    _two_caps(snap, setup)
    v.set_pi_markers(ac_markers(snap, setup, {"VOUT"}))
    v.set_pi_selected(("cap", "10u"))
    assert v._pi_actors["pi_selected_dots"].GetMapper().GetInput().GetNumberOfPoints() == 2
    assert v._blink_timer.active


def test_clicking_a_capacitor_in_3d_selects_its_model(app, no_3d, monkeypatch):
    w = _ac_window(monkeypatch)
    _two_caps(w.snapshot, w.ac_panel.setup)
    w.ac_panel.cap_list.reload()
    c2 = next(m for m in ac_markers(w.snapshot, w.ac_panel.setup, {"VOUT"}) if m.name == "C2")
    monkeypatch.setattr(w.viewer, "pi_marker_at", lambda xy: c2)
    w._on_click(None, (10, 10))
    assert w.ac_panel.tabs.currentWidget() is w.ac_panel.cap_list
    assert w.ac_panel.cap_list.current().name == "10u"
    assert "10u" in w.statusBar().currentMessage()
    w.close()


def test_clicking_a_marker_in_ac_mode_selects_it_in_the_ac_setup(app, no_3d, monkeypatch):
    w = _ac_window(monkeypatch)
    probe = next(m for m in ac_markers(w.snapshot, w.ac_panel.setup, {"VOUT"})
                 if m.kind == "probe")
    monkeypatch.setattr(w.viewer, "pi_marker_at", lambda xy: probe)
    w._on_click(None, (10, 10))
    assert w.ac_panel.tabs.currentWidget() is w.ac_panel.probe_list
    assert w.ac_panel.probe_list.current().name == "U2 core"
    assert w.solve_panel.tabs.currentWidget() is not w.solve_panel.load_list
    w.close()


def test_the_hot_loops_are_drawn_in_their_colours():
    """Coupled Noise's hot loops (#178): a tube, cones and a name per loop; hidden over
    results, removed with None."""
    from kipi.noise.viz import LoopOverlay, LoopPath
    v = _view()
    segs = np.array([[[0, 0, 1.5], [4, 0, 1.5]], [[4, 0, 1.5], [4, 0, 1.3]]], float)
    loop = LoopPath("C1 (phase 1)", "C1", segs, np.array([[2, 0, 1.5]]),
                    np.array([[1, 0, 0]]), "#ff9a1f", np.array([0, 0, 1.5]))
    v.set_hot_loops(LoopOverlay([loop, loop], "two"))
    assert len(v._hot_loop_actors) == 6 and v._hot_loops.note == "two"
    mapper = v._hot_loop_actors[0].GetMapper()
    mapper.Update()
    tube = pv.wrap(mapper.GetInput())
    assert tube.n_cells == 2
    np.testing.assert_allclose(tube.points[1], (4, 0, 1.5))
    np.testing.assert_allclose(v._hot_loop_actors[0].GetProperty().GetColor(),
                               pv.Color("#ff9a1f").float_rgb, atol=1e-6)
    cones = pv.wrap(v._hot_loop_actors[1].GetMapper().GetInput())
    assert cones.n_points > 0 and cones.bounds[0] >= 2.0 - 1e-6     # the cone starts at its point
    assert v._hot_loop_actors[2].GetMapper().GetInputDataObject(0, 0).GetPointData() \
        .GetAbstractArray("names").GetValue(0) == "C1"
    v._result = object()
    v._apply_visibility()
    assert not any(a.GetVisibility() for a in v._hot_loop_actors)
    v._result = None
    v.set_zscale(2.0)
    assert len(v._hot_loop_actors) == 6 and v._hot_loop_actors[0].GetScale()[2] == 2.0
    v.set_hot_loops(None)
    assert v._hot_loop_actors == [] and v._hot_loops is None


def test_a_field_slice_is_drawn_and_animated():
    """Coupled Noise's field slice (#146): a coloured plane with arrows; frames step its
    scalars; hidden over results, removed with None."""
    from kipi.noise.viz import FieldOverlay
    v = _view()
    nx, ny = 6, 5
    gx, gy = np.meshgrid(np.arange(nx) * 1.0, np.arange(ny) * 1.0)
    pts = np.column_stack([gx.ravel(), gy.ravel(), np.full(gx.size, 2.0)])
    mag = 1.0 + pts[:, 0]
    vec = np.column_stack([np.zeros(len(pts)), np.zeros(len(pts)), mag])
    frames = np.stack([vec * 0.5, vec * 0.25]).astype(np.float32)
    ov = FieldOverlay("H field (A/m)", "A/m", pts, nx, ny, mag, vec, (0.01, 10.0), frames, 40, "n")
    v.set_fields(ov)
    assert len(v._field_actors) == 2 and v._fields is ov and v._field_timer.active
    mapper = v._field_actors[0].GetMapper()
    mapper.Update()
    mesh = pv.wrap(mapper.GetInput())
    assert mesh.n_cells == (nx - 1) * (ny - 1) and mesh.n_points == nx * ny
    np.testing.assert_allclose(mesh.point_data["field"], mag)
    np.testing.assert_allclose(mesh.points[1], (1.0, 0.0, 2.0))       # y flipped: 0 stays 0
    assert v._field_bar == "H field (A/m)"
    v._field_step()
    assert v._field_frame == 1
    np.testing.assert_allclose(mesh.point_data["field"], np.maximum(mag * 0.25, 0.01))
    v._result = object()
    v._apply_visibility()
    assert not any(a.GetVisibility() for a in v._field_actors)
    v._result = None
    v.set_zscale(2.0)
    assert v._field_actors[0].GetScale()[2] == 2.0
    v.set_fields(None)
    assert v._field_actors == [] and v._fields is None and not v._field_timer.active
    assert v._field_bar is None


def test_a_victims_coupling_is_drawn_over_the_copper():
    """Coupled Noise's overlay (#152): the victim's segments colored by their share and
    the common-ground dot; hidden over results, removed with None."""
    from kipi.noise.viz import CouplingOverlay
    v = _view()
    segs = np.array([[[0, 0, 1.5], [1, 0, 1.5]], [[1, 0, 1.5], [2, 0, 1.5]]], float)
    ov = CouplingOverlay("Superposition share of the peak (mV)", segs, np.array([2.0, -1.0]),
                         np.array([[0, 0, 1.5]]), np.array([0.5]), 2.0)
    v.set_coupling(ov)
    assert len(v._coupling_actors) == 2 and v._coupling_bar == ov.title
    mapper = v._coupling_actors[0].GetMapper()
    mapper.Update()                     # the mesh reaches the mapper through its pipeline
    victim = pv.wrap(mapper.GetInput())
    assert victim.n_cells == 2
    np.testing.assert_allclose(victim.points[3], (2, 0, 1.5))
    assert v._coupling_actors[0].GetMapper().GetScalarRange() == (-2.0, 2.0)
    v._result = object()
    v._apply_visibility()
    assert not any(a.GetVisibility() for a in v._coupling_actors)
    v._result = None
    v.set_zscale(3.0)
    assert v._coupling_actors[0].GetScale() == (1.0, 1.0, 3.0)
    v.set_coupling(None)
    assert v._coupling_actors == [] and v._coupling_bar is None
    assert ov.title not in v.plotter.scalar_bars
